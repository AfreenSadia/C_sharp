﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTryYourself
{
    internal class Program
    {

        static void Main(string[] args)
        {
            ABC_Company.FirstView();//SIR,I USED USER INPUT .

            /*int r;
            ABC_Company.AddEmployee(new ITExecutive("SAYERA",25000, new DateTime(2023,02,25),25000,3000));
            //ABC_Company.AddEmployee(new ITExecutive("SAYERA",25000, new DateTime(2023,02,25),50000,3000));
            //ABC_Company.AddEmployee(new Manager("ABRAR",50000, new DateTime(2023,01,12),20000,15000));
            ABC_Company.AddEmployee(new PartTime("ANITA",20000, new DateTime(2023,01,01),35000));
            ABC_Company.AddEmployee(new ITExecutive("SAYED", 25000, new DateTime(2023, 02, 25), 45000, 3000));
            ABC_Company.AddEmployee(new PartTime("ARNO",27000, new DateTime(2023, 01, 09),11000));
            ABC_Company.AddEmployee(new Manager("Hamim", 58000, new DateTime(2022, 10, 05), 25000, 1000));
            ABC_Company.ShowAll();
            ABC_Company.Search( Console.ReadLine(),out r);
            ABC_Company.DeleteEmployee( Console.ReadLine());
            ABC_Company.Exit(true);*/
        }

    }
}


            

        
    

